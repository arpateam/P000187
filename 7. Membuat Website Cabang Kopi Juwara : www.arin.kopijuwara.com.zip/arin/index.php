<?php

    $nama_web       = "Dahsyatnya Minum Kopi Juwara";
    $slogan         = "Memberikan Kesegaran, Kesehatan dan Menambah Penghasilan";

    // $base_url       = "https://www.arin.kopijuwara.com";
    $base_url       = "http://localhost/project/P000186/arin";
    $domain         = "www.kopijuwara.com";

    $alamat         = "(Perumahan BSD City) Jl. Cemara Raya Blok B1/5 Sektor 1.1, Kec. Serpong  Kel. Rawabuntu, BSD City, Tangerang Selatan - 15318";
    $nomorWhatsApp  = "6287711877590";

    $title          = $nama_web." - ".$slogan;
    $keyword        = "Dahsyatnya Minum Kopi Juwara - Memberikan Kesegaran, Kesehatan dan Menambah Penghasilan. Karena Mengandung 100% biji kopi premium dari Brazil, ditambah creamer menggunakan minyak kelapa berkualitas tinggi dan tanpa lemak trans, dipadukan dengan Yung Kien Ganoderma yang baik untuk kesehatan dan dapat meningkatkan imunitas.";
    $description    = "Dahsyatnya Minum Kopi Juwara - Memberikan Kesegaran, Kesehatan dan Menambah Penghasilan. Karena Mengandung 100% biji kopi premium dari Brazil, ditambah creamer menggunakan minyak kelapa berkualitas tinggi dan tanpa lemak trans, dipadukan dengan Yung Kien Ganoderma yang baik untuk kesehatan dan dapat meningkatkan imunitas.";

    // if (isset($_POST['_submit_special_ARPATEAM_'])) {
    //     $nama               = $_POST['___in_nama_special_ARPATEAM'];
    //     $nomor_whatsapp     = $_POST['___in_nomor_whatsapp_special_ARPATEAM'];
    //     $email              = $_POST['___in_email_special_ARPATEAM'];
    //     $metode_pembayaran  = $_POST['___in_metode_pembayaran_special_ARPATEAM'];

    //     $linkWA = "https://api.whatsapp.com/send?phone=6281392374988&text=Hallo%20Maheswari%20Business%2C%0A%0ASaya%20mau%20ambil%20Promo%20%2B%20Bonusnya.%0A%0ANama%3A%20".$nama."%0ANomor%20WhatsApp%3A%20".$nomor_whatsapp."%0AEmail%3A%20".$email."%0AMetode%20Pembayaran%3A%20".$metode_pembayaran;

    //     echo "<script>window.location = '$linkWA'</script>";
    // }
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="google" content="notranslate" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">

    <meta name="googlebot" content="index,follow">
    <meta name="googlebot-news" content="index,follow">
    <meta name="robots" content="index,follow">
    <meta name="Slurp" content="all">

    <title><?= $title ?></title>
    <meta content="<?= $title ?>" name="title">
    <meta content="<?= $description ?>" name="description">
    <meta content="<?= $keyword ?>" name="keywords">
    <!-- Favicons -->
    <link href="<?= $base_url ?>/assets/img/icon-kopi-juwara.png" rel="icon">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="article">
    <meta property="og:image" content="<?= $base_url ?>/assets/img/icon-kopi-juwara.png">
    <meta property="og:title" content="<?= $title ?>">
    <meta property="og:description" content="<?= $description ?>">
    <meta property="og:url" content="<?= $base_url ?>">
    <meta property="og:site_name" content="<?= $nama_web ?>">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:site" content="<?= $nama_web ?>" />
    <meta property="twitter:url" content="<?= $base_url ?>">
    <meta property="twitter:title" content="<?= $title ?>">
    <meta property="twitter:description" content="<?= $description ?>">
    <meta property="twitter:image" content="<?= $base_url ?>/assets/img/icon-kopi-juwara.png">
        
    <link rel="canonical" href="<?= $base_url ?>">
    <link rel="shortlink" href="<?= $base_url ?>">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <!-- Vendor CSS Files -->
    <link href="<?= $base_url ?>/assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="<?= $base_url ?>/assets/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="<?= $base_url ?>/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= $base_url ?>/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="<?= $base_url ?>/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="<?= $base_url ?>/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="<?= $base_url ?>/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <!-- Template Main CSS File -->
    <link href="<?= $base_url ?>/assets/css/style.css" rel="stylesheet">
    <link href="<?= $base_url ?>/assets/css/bg.css" rel="stylesheet">
</head>
<body onmousedown="return false" onselectstart="return false">
    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top d-flex align-items-center header-transparent">
        <div class="container d-flex align-items-center justify-content-between">
            <div class="logo">
                <a href="<?= $base_url ?>"><img src="<?= $base_url ?>/assets/img/logo-kopi-juwara.png" alt="Logo <?= $nama_web ?>" class="img-fluid"></a>
            </div>
            <a target="_blank" href="https://api.whatsapp.com/send?phone=<?= $nomorWhatsApp ?>&text=Saya%20tertarik%20dengan%20Kopi%20Juwara.%0AMohon%20Infonya%2C%20Terimakasih." class="nav-link d-inline d-lg-none" href="#promo"><span class="btn btn-warning"><i class="bi bi-whatsapp"></i> Ambil Promo Sekarang</span></a>
            <nav id="navbar" class="navbar">
                <ul>
                    <!-- <li>
                        <a class="nav-link scrollto active" href="#hero">Beranda</a>
                    </li> -->
                    <li>
                        <a class="nav-link scrollto" href="#ProfilPerusahaan">Profil Perusahaan</a>
                    </li>
                    <li>
                        <a class="nav-link scrollto" href="#Testimoni">Testimoni</a>
                    </li>
                    <li>
                        <a class="nav-link scrollto" href="#Manfaat">Manfaat</a>
                    </li>
                    <li>
                        <a class="nav-link scrollto" href="#Produk">Produk</a>
                    </li>
                    <li>
                        <a class="nav-link scrollto" href="#Cuan">Dapat Cuan</a>
                    </li>
                    <li>
                        <a target="_blank" href="https://api.whatsapp.com/send?phone=<?= $nomorWhatsApp ?>&text=Saya%20tertarik%20dengan%20Kopi%20Juwara.%0AMohon%20Infonya%2C%20Terimakasih." class="nav-link" href="#promo"><span class="btn btn-warning"><i class="bi bi-whatsapp"></i> Ambil Promo</span></a>
                    </li>
                </ul>
                <i class="bi bi-list mobile-nav-toggle"></i>
            </nav>
            <!-- .navbar -->
        </div>
    </header>
    <!-- End Header -->
    <!-- ======= Hero Section ======= -->
    <section id="hero">
        <div class="container">
            <div class="row justify-content-between py-0 py-md-2 py-lg-4">
                <div class="col-lg-5 col-xl-6 my-auto pt-5 pt-lg-0 order-2 order-lg-1 text-center text-lg-start d-flex align-items-center">
                    <div data-aos="zoom-out">
                        <h3 class="text-light">Agen Kopi Juwara</h3>
                        <h1><span>Dahsyatnya</span> Minum Kopi Juwara</h1>
                        <h5 class="text-light">(Memberikan Kesegaran, Kesehatan dan Menambah Penghasilan)</h5>
                        <center>
                            <img src="<?= $base_url ?>/assets/img/banner-kopi-juwara-v7.png" class="w-75 mt-4 rounded animated d-block d-lg-none" alt="Gambar Banner <?= $nama_web ?>">
                        </center>
                        <p class="mt-4 text-light">Mengandung <strong>100% biji kopi premium dari Brazil</strong>, ditambah creamer menggunakan minyak kelapa berkualitas tinggi dan tanpa lemak trans, dipadukan dengan <strong>Yung Kien Ganoderma</strong> yang baik untuk kesehatan dan dapat meningkatkan imunitas.</p>
                        <h1 class="text-uppercase"><span>MODAL:</span> 155k <small class="fs-6 text-capitalize fw-normal">(Belum Ongkir)</small></h1>
                        <a href="#Pembayaran" class="fst-italic text-warning"><span>NB:</span> Ongkir lihat tabel di bawah <i class="bi bi-chevron-double-down"></i></a>
                        <div class="text-center text-lg-start mt-4">
                            <a target="_blank" href="https://api.whatsapp.com/send?phone=<?= $nomorWhatsApp ?>&text=Saya%20tertarik%20dengan%20Kopi%20Juwara.%0AMohon%20Infonya%2C%20Terimakasih." class="btn-get-started scrollto"><i class="bi bi-whatsapp"></i> Ambil Promo Sekarang</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5 my-auto order-1 order-lg-2 hero-img d-none d-lg-block" data-aos="zoom-out" data-aos-delay="300">
                    <img src="<?= $base_url ?>/assets/img/banner-kopi-juwara-v7.png" class="img-fluid rounded animated" alt="Gambar Banner <?= $nama_web ?>">
                </div>
            </div>
        </div>
        <svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none">
            <defs>
                <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z">
            </defs>
            <g class="wave1">
                <use xlink:href="#wave-path" x="50" y="3" fill="rgba(255,255,255, .1)">
            </g>
            <g class="wave2">
                <use xlink:href="#wave-path" x="50" y="0" fill="rgba(255,255,255, .2)">
            </g>
            <g class="wave3">
                <use xlink:href="#wave-path" x="50" y="9" fill="#fff">
            </g>
        </svg>
    </section>
    <!-- End Hero -->
    <main id="main">
        <!-- ======= Profil Perusahaan ======= -->
        <section id="ProfilPerusahaan" class="details">
            <div class="container">
                <div class="row justify-content-center mb-4" data-aos="fade-up">
                    <div class="col-md-8 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/profil-perusahaan/judul.png" class="img-fluid rounded animated" alt="Gambar Judul Profil Perusahaan <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-10 col-lg-9 col-xl-8">
                        <h2 class="text-center fw-bolder" style="color: #734619 !important;">SHUANG HOR Indonesia</h2>
                        <p class="text-muted">PT. Shuang Hor Indonesia merupakan perusahaan asing asal Taiwan yang telah melakukan bisnisnya di Indonesia selama lebih dari 15 tahun, yaitu perusahaan yang memproduksi SH Juwara Cafe. Produk-produk Shuang Hor yang beredar di Indonesia beraneka ragam, dengan kualitas terbaik diharapkan dapat memberikan kesehatan untuk semua kalangan masyarakat Indonesia pada khususnya dengan harga yang sangat terjangkau yang menjadikan Shuang Hor Indonesia tetap bertahan menjalani bisnisnya di Indonesia.</p>
                        <p class="text-muted">Agen PT. Shuang Hor berada di seluruh nusantara bahkan di luar negeri. Untuk Indonesia sudah ada beberapa kantor cabang sudah ada di beberapa kota seperti : Jakarta, Medan, Batam, Palembang, Pekanbaru dan Tanjung Balai. Menyusul beberapa kota besar akan buka di Indonesia. </p>
                    </div>

                    <div class="w-100 my-3"></div>
                    
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/profil-perusahaan/gambar-1.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Profil Perusahaan 1 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/profil-perusahaan/gambar-2.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Profil Perusahaan 2 <?= $nama_web ?>">
                    </div>

                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/profil-perusahaan/gambar-3.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Profil Perusahaan 3 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/profil-perusahaan/gambar-4.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Profil Perusahaan 4 <?= $nama_web ?>">
                    </div>
                </div>
            </div>
        </section>

        <!-- ======= Testimoni ======= -->
        <section id="Testimoni" class="pricing" style="background-color: #734619">
            <div class="container">
                <div class="row justify-content-center mb-4" data-aos="fade-up">
                    <div class="col-10 col-md-8 col-lg-6 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/judul.png" class="img-fluid rounded animated" alt="Gambar Judul Testimoni <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-1.png" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 1 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-2.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 2 <?= $nama_web ?>">
                    </div>

                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-3.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 3 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-4.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 4 <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center my-4" data-aos="fade-up">
                    <div class="col-10 col-md-8 col-lg-6 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-5.png" class="img-fluid rounded animated" alt="Gambar Judul Testimoni <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-6.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 6 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-7.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 7 <?= $nama_web ?>">
                    </div>

                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-8.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 8 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-9.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 9 <?= $nama_web ?>">
                    </div>

                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-10.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 10 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-11.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 11 <?= $nama_web ?>">
                    </div>

                    <div class="col-md-6 col-lg-5 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/testimoni/gambar-12.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Testimoni 12 <?= $nama_web ?>">
                    </div>
                </div>
            </div>
        </section>

        <!-- ======= Manfaat ======= -->
        <section id="Manfaat" class="details">
            <div class="container">
                <div class="row justify-content-center mb-2" data-aos="fade-up">
                    <div class="col-md-8 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/manfaat/judul.png" class="img-fluid rounded animated" alt="Gambar Judul Manfaat <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-10 col-lg-9 col-xl-8">
                        <p class="text-muted">SH Juwara Cafe adalah merk kopi yang dibuat dari biji kopi Arabica pilihan dari Brazil  telah hadir di Indonesia setelah penantian bertahun tahun untuk mendapatkan perizinan, kini hadir dengan marketing plan yang menarik serta memberikan keuntungan yang besar bagi agent SH Juwara Cafe.</p>
                        <p class="text-muted">Mengandung 100% biji kopi premium dari Brazil, ditambah creamer menggunakan minyak kelapa berkualitas tinggi dan tanpa lemak trans, dipadukan dengan Yung Kien Ganoderma yang baik untuk kesehatan hati serta meningkatkan imunitas.</p>
                        <p class="text-muted">Satu cangkir kopi SH Juwara Cafe akan memberikan kesegaran, kesehatan dan menambah penghasilan.</p>
                    </div>

                    <div class="w-100 my-3"></div>
                    
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/manfaat/gambar-1.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Manfaat 1 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/manfaat/gambar-2.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Manfaat 2 <?= $nama_web ?>">
                    </div>

                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/manfaat/gambar-3.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Manfaat 3 <?= $nama_web ?>">
                    </div>
                </div>
            </div>
        </section>

        <!-- ======= Produk ======= -->
        <section id="Produk" class="pricing" style="background-color: #734619">
            <div class="container">
                <div class="row justify-content-center mb-4" data-aos="fade-up">
                    <div class="col-10 col-md-8 col-lg-6 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/produk/judul.png" class="img-fluid rounded animated" alt="Gambar Judul Produk <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-6 col-lg-6 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/produk/gambar-1.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Produk 1 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-6 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/produk/gambar-2.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Produk 2 <?= $nama_web ?>">
                    </div>
                </div>
            </div>
        </section>

        <!-- ======= Cuan ======= -->
        <section id="Cuan" class="details">
            <div class="container">
                <div class="row justify-content-center mb-2" data-aos="fade-up">
                    <div class="col-md-8 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/judul.png" class="img-fluid rounded animated" alt="Gambar Judul Cuan <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-1.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 1 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-2.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 2 <?= $nama_web ?>">
                    </div>

                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-3.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 3 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-4.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 4 <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center my-4" data-aos="fade-up">
                    <div class="col-md-8 col-xl-6 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-5.png" class="img-fluid rounded animated" alt="Gambar Judul Cuan <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-6.png" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 6 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-7.png" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 7 <?= $nama_web ?>">
                    </div>

                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-8.png" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 8 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-9.png" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 9 <?= $nama_web ?>">
                    </div>

                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-10.png" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 10 <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center my-4" data-aos="fade-up">
                    <div class="col-md-8 col-xl-6 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-11.png" class="img-fluid rounded animated" alt="Gambar Judul Cuan <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-12.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 12 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-13.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 13 <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center my-4" data-aos="fade-up">
                    <div class="col-md-8 col-xl-6 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-14.png" class="img-fluid rounded animated" alt="Gambar Judul Cuan <?= $nama_web ?>">
                    </div>
                </div>

                <div class="row justify-content-center" data-aos="fade-up">
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-15.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 15 <?= $nama_web ?>">
                    </div>
                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-16.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 16 <?= $nama_web ?>">
                    </div>

                    <div class="col-md-6 col-lg-5 my-auto py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                        <img src="<?= $base_url ?>/assets/img/cuan/gambar-17.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Cuan 17 <?= $nama_web ?>">
                    </div>
                </div>
            </div>
        </section>

        <section id="Pembayaran" class="rekening">
            <div class="container">
                <div class="card shadow text-center p-4" data-aos="fade-up" style="background-color: #734619">
                    <div class="row justify-content-center mb-4" data-aos="fade-up">
                        <div class="col-10 col-md-8 text-center" data-aos="fade-up">
                            <img src="<?= $base_url ?>/assets/img/metode-pembayaran/judul.png" class="img-fluid rounded animated" alt="Gambar Judul Metode Pembayaran <?= $nama_web ?>">
                        </div>
                    </div>

                    <div class="row justify-content-center" data-aos="fade-up">
                        <div class="col-md-8 col-lg-7 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                            <img src="<?= $base_url ?>/assets/img/metode-pembayaran/gambar-1.jpg" class="img-fluid shadow-sm rounded animated" alt="Gambar Metode Pembayaran 1 <?= $nama_web ?>">
                        </div>
                    </div>

                    <h1 class="fw-bolder my-4 text-center text-light" data-aos="fade-down">METODE PEMBAYARAN</h1>
                    <div class="row justify-content-center content">
                        <div class="col-md-10 col-lg-6 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                            <img src="<?= $base_url ?>/assets/img/foto/arin.jpeg" class="img-fluid shadow rounded animated" alt="Gambar Foto Arin <?= $nama_web ?>">
                        </div>
                        <div class="col-md-10 col-lg-6 py-3 px-3 px-md-4 px-lg-5 order-2 order-md-1 text-center" data-aos="fade-up">
                            <img src="<?= $base_url ?>/assets/img/metode-pembayaran/gambar-3.png" class="img-fluid shadow rounded animated" alt="Gambar Metode Pembayaran 3 <?= $nama_web ?>">
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <!-- End #main -->
    <!-- ======= Footer ======= -->
    <footer id="footer">
        <div class="container">
            <div class="copyright"> &copy; <?= date("Y") ?> <strong><a target="_blank" href="<?= $base_url ?>" title="Website <?= $nama_web ?>"><?= $nama_web ?></a></strong>. All Rights Reserved</div>
            <div class="credits">
                <!-- All the links in the footer should remain intact. -->
                <!-- You can delete the links only if you purchased the pro version. -->
                <!-- Licensing information: https://bootstrapmade.com/license/ -->
                <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bootslander-free-bootstrap-landing-page-template/ --> Website by <strong><a target="_blank" href="https://arpateam.com" title="Website #ARPATEAM">#ARPATEAM</a></strong>
            </div>
        </div>

    <a id="whatsappButton" class="text-success" target="_blank" href="https://api.whatsapp.com/send?phone=<?= $nomorWhatsApp ?>&text=Saya%20tertarik%20dengan%20Kopi%20Juwara.%0AMohon%20Infonya%2C%20Terimakasih."><i class="bi bi-whatsapp"></i></a>
    </footer>
    <!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center">
        <i class="bi bi-arrow-up-short"></i>
    </a>
    <div id="preloader"></div>
    <!-- Vendor JS Files -->
    <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>
    <script>
        function copyRekening() {
            /* Get the text field */
            var copyText = document.getElementById("myRekening");

            /* Select the text field */
            copyText.select();
            copyText.setSelectionRange(0, 99999); /* For mobile devices */

           /* Copy the text inside the text field */
            navigator.clipboard.writeText(copyText.value);

            /* Alert the copied text */
            alert("Copied the text: " + copyText.value);
        }
    </script>
</body>
</html>